package com.pack;

public interface LambdaExample1 {
	public void add(int a);
}
