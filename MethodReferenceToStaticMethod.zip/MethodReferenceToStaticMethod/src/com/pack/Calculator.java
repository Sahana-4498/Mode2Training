package com.pack;

public class Calculator {
public static void disp(){
	System.out.println("Calculating");
}
public static int add(int a,int b){
	return a+b;
}
}
