package com.pack;

public interface LambdaExample {
public void display();

}
