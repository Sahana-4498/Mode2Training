import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class DateAndTime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DateAndTime dt = new DateAndTime();
		dt.localDateTime();
	}

	public void localDateTime() {
		LocalTime t = LocalTime.now();
		System.out.println("Time: " + t);
		LocalDateTime dt = LocalDateTime.now();
		System.out.println("Date and Time: " + dt);
		LocalDate d = LocalDate.now();
		System.out.println("Date: " + d);
		LocalDate date1 = dt.toLocalDate();
		System.out.println("date1: " + date1);
		int day = dt.getDayOfMonth();
		Month month = dt.getMonth();
		int year = dt.getYear();
		DayOfWeek week = dt.getDayOfWeek();
		System.out.println("Day:" + day + " " + "Month:" + month + " " + "Year:" + year + " " + "Week:" + week);
		LocalDateTime date2 = dt.withDayOfMonth(28).withYear(2019);
		System.out.println("date2: " + date2);
		int hours = dt.getHour();
		int min = dt.getMinute();
		int sec = dt.getSecond();
		System.out.println("Hours:" + hours + " " + "Minutes:" + min + " " + "Seconds:" + sec);

		ZonedDateTime date3 = ZonedDateTime.parse("2007-12-03T10:15:30+05:30[Asia/Bangkok]");
		System.out.println("date3: " + date3);

		ZoneId id = ZoneId.of("Europe/Paris");
		System.out.println("ZoneId: " + id);

		ZoneId currentZone = ZoneId.systemDefault();
		System.out.println("CurrentZone: " + currentZone);
	}
}
