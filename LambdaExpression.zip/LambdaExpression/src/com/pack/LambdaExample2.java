package com.pack;
public interface LambdaExample2 {
	public   void sub(int a,int b);
}
