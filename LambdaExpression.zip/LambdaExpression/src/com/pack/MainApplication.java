package com.pack;
public  class MainApplication {
	public static void main(String[] args) {
		LambdaExample l4=()->System.out.println("Hello");
		l4.display();
		LambdaExample1 l1=(int a)->System.out.println(a+a);
		l1.add(2);
		LambdaExample2 l2=(int a,int b)->System.out.println(b-a);
		l2.sub(5, 10);
		LambdaExample3 l3=(int l,int b,int h)->System.out.println(l*b*h);
		l3.area(2, 3, 6);
		
	}
	
}
