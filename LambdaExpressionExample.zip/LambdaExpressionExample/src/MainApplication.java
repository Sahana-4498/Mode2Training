import java.util.ArrayList;
import java.util.List;
public class MainApplication {
	public static void main(String[] args) {
		Person p1 = new Person(21, "Sahana");
		Person p2 = new Person(23, "Sagar");
		Person p3 = new Person(42, "Mamatha");
		Person p4 = new Person(60, "Moganna");
		List<Person> list = new ArrayList<Person>();
		list.add(p1);
		list.add(p2);
		list.add(p3);
		list.add(p4);
		list.forEach(i -> {
			if (i.name.charAt(0) == 'S')
				System.out.println(i.name);
		});
		list.forEach(i -> {
			if (i.name.startsWith("S"))
				System.out.println(i.name);
		});

	}
}
