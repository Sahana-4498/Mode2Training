package com.pack;

public interface Display {
void say();
}
