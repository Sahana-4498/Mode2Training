package com.pack;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Repeatable(Customers.class)
@interface Customer1{
String name();
int age();
}
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@interface Customers{
Customer1[] value();
}
@Customer1(name="Sahana",age=21)
@Customer1(name="Sagar",age=23)
public class RepetableAnnotation {
	public static void main(String[] args) {
		Customer1[] cust=RepetableAnnotation.class.getAnnotationsByType(Customer1.class);
		for(Customer1 customer:cust)
			
		System.out.println(customer.name()+" "+customer.age());
		
	}
	
}
