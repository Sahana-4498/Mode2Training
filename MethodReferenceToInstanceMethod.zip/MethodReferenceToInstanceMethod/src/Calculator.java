

public class Calculator {
public void disp(){
	System.out.println("Calculating");
}
public  int add(int a,int b){
	return a+b;
}
}
