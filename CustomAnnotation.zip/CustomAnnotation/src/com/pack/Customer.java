package com.pack;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@interface MyAnnotation{  
int age();  
String name();
}  
@MyAnnotation(name="sahana",age=21)
public class Customer {
	public static void main(String[] args) {
		MyAnnotation m=Customer.class.getAnnotation(MyAnnotation.class);
		System.out.println(m.name()+" "+m.age());
	}

}
