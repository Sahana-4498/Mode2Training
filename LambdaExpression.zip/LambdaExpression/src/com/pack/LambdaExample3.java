package com.pack;
public interface LambdaExample3 {
	public  void area(int l,int b,int h);
}
