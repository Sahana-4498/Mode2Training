

public interface Display {
void say();
}
