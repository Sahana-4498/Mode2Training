import java.util.function.BiFunction;

public class MainApplication {
public static void main(String[] args) {
	Calculator cal=new Calculator();
	Display display = cal::disp;
	display.say();
	BiFunction<Integer, Integer, Integer>adder = new Calculator()::add;  
	int result = adder.apply(30, 20);  
	System.out.println(result);  
}
}
